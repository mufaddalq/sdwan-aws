import json
import logging
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_vpn_attachment_ids(vpn1_id, vpn2_id):
    try:
      myDict = {}
      client = boto3.client('ec2')
      vpn = client.describe_vpn_connections(VpnConnectionIds=[vpn1_id,vpn2_id])['VpnConnections']
      logger.info(boto3.__version__)
      logger.info(vpn)
      myDict['vpn_tgw_attach_id1'] = vpn[0]['TransitGatewayId']
      myDict['vpn_tgw_attach_id2'] = vpn[1]['TransitGatewayId']
      #for i,dict in enumerate(vpn):
      #  myDict['vpn_tgw_attach_id' + str(i)] = vpn[i]['TransitGatewayId']
    except Exception as e:
      logger.info('get vpn tgw attachment id failure: {}'.format(e))

    return myDict

def lambda_handler(event, context):
    logger.info('got event {}'.format(event))
    
    if event['RequestType'] == 'Create':
      responseData = get_vpn_attachment_ids(event['ResourceProperties']['vpn1_id'],event['ResourceProperties']['vpn2_id'])
    
    else: # delete / update
      responseData = event['PhysicalResourceId'] 
    
    logger.info('responseData {}'.format(responseData))
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)